<?php

    return [
        'name'          =>  'CRUD Generator',
        'description'   =>  'Modul CRUD Generator untuk mempermudah pembuatan modul baru',
        'author'        =>  'Basoro',
        'version'       =>  '1.0',
        'compatibility' =>  '4.0.*',
        'icon'          =>  'code-s-slash-line',
        'help'          =>  '',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
