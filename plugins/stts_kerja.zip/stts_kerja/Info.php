<?php

    return [
        'name'          =>  'Stts Kerja',
        'description'   =>  'Modul stts kerja untuk mLITE',
        'author'        =>  'Basoro',
        'version'       =>  '1.0',
        'compatibility' =>  '4.0.*',
        'icon'          =>  'corner-down-right-fill',
        'help'          =>  '',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
